<?php 

// Identifiants à la BDD
define("DB_SERVER", "localhost");
define("DB_NAME", "blogmmi");
define("DB_USER", "test");
define("DB_PASSWORD", "test");

?>